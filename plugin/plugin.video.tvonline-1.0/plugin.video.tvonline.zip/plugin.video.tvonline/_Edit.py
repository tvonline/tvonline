import xbmcaddon

MainBase = 'http://pastebin.com/raw/bXNdxDfC'
addon = xbmcaddon.Addon('plugin.video.tvonline')